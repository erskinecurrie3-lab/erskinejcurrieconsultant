import UnifiedSettings from '@/components/shared/UnifiedSettings';

export default function AdminSettings() {
  return <UnifiedSettings />;
}