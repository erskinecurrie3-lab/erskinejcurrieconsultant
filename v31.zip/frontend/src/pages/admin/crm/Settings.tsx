import UnifiedSettings from '@/components/shared/UnifiedSettings';

export default function CRMSettings() {
  return <UnifiedSettings />;
}