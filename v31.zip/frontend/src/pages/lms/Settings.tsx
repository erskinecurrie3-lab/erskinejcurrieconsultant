import UnifiedSettings from '@/components/shared/UnifiedSettings';

export default function LMSSettings() {
  return <UnifiedSettings />;
}