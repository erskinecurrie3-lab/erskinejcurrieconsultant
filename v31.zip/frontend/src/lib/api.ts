import { createClient } from '@metagptx/web-sdk';

export const client = createClient();