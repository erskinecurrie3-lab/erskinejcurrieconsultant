# Resend API Migration Guide

## Overview
This document outlines the migration from SendGrid to Resend API for all email functionality in the Erskine J Currie Ministry Consulting platform.

## Migration Summary

### Files Updated
1. **`/workspace/app/backend/functions/email-automation.ts`**
   - Replaced SendGrid API endpoint with Resend API endpoint
   - Updated authentication from `Authorization: Bearer SENDGRID_API_KEY` to `Authorization: Bearer RESEND_API_KEY`
   - Changed request payload format to match Resend's API structure
   - Updated error handling for Resend-specific responses

2. **`/workspace/app/backend/functions/email-templates.ts`**
   - Updated comments to reference Resend instead of SendGrid
   - Templates remain compatible (HTML/text format unchanged)
   - Template rendering functions remain the same

3. **`/workspace/app/backend/functions/scheduled-tasks.ts`**
   - No changes required (uses email-automation functions)
   - All scheduled tasks continue to work with new Resend integration

4. **`/workspace/app/backend/functions/webhooks.ts`**
   - No changes required (uses email-automation functions)
   - All webhook handlers continue to work with new Resend integration

## API Changes

### SendGrid → Resend API Differences

#### Endpoint
- **SendGrid**: `https://api.sendgrid.com/v3/mail/send`
- **Resend**: `https://api.resend.com/emails`

#### Authentication
- **SendGrid**: `Authorization: Bearer SENDGRID_API_KEY`
- **Resend**: `Authorization: Bearer RESEND_API_KEY`

#### Request Payload Format

**SendGrid Format:**
```json
{
  "personalizations": [{ "to": [{ "email": "user@example.com" }] }],
  "from": { "email": "hello@erskinecurrie.com", "name": "Erskine J Currie Ministries" },
  "subject": "Email Subject",
  "content": [
    { "type": "text/plain", "value": "Plain text content" },
    { "type": "text/html", "value": "<html>HTML content</html>" }
  ]
}
```

**Resend Format:**
```json
{
  "from": "Erskine J Currie Ministries <hello@erskinecurrie.com>",
  "to": ["user@example.com"],
  "subject": "Email Subject",
  "html": "<html>HTML content</html>",
  "text": "Plain text content"
}
```

## Environment Variables

### Required Update
Replace the SendGrid API key with Resend API key in your environment configuration:

**Before:**
```bash
SENDGRID_API_KEY=SG.xxxxxxxxxxxxxxxxxxxxx
```

**After:**
```bash
RESEND_API_KEY=re_xxxxxxxxxxxxxxxxxxxxx
```

## Email Functions (Unchanged)

All email functions maintain the same interface and can be called identically:

- `sendNewLeadWelcome(email, name)`
- `sendLeadFollowUp(email, name, leadStage)`
- `sendEventConfirmation(email, name, eventTitle, eventDate, eventLocation)`
- `sendEventReminder(email, name, eventTitle, eventDate, eventLocation)`
- `sendPostEventFeedback(email, name, eventTitle)`
- `sendClientWelcome(email, name, churchName)`
- `sendResourceDownload(email, name, resourceTitle)`
- `sendAbandonedBookingReminder(email, name)`
- `sendWeeklyReport(email, reportData)`

## Testing Checklist

- [ ] Update `RESEND_API_KEY` in environment variables
- [ ] Test welcome email for new leads
- [ ] Test event registration confirmation
- [ ] Test event reminder (24h before)
- [ ] Test post-event feedback request
- [ ] Test client welcome email
- [ ] Test resource download confirmation
- [ ] Test abandoned booking reminder
- [ ] Test weekly report generation
- [ ] Verify all scheduled tasks execute correctly
- [ ] Verify all webhook handlers send emails correctly

## Benefits of Resend

1. **Simpler API**: More intuitive request/response format
2. **Better Developer Experience**: Cleaner API design
3. **Modern Infrastructure**: Built for modern applications
4. **Reliable Delivery**: High deliverability rates
5. **Transparent Pricing**: Clear and predictable costs

## Rollback Plan

If issues arise, revert the following files to their previous versions:
- `/workspace/app/backend/functions/email-automation.ts`
- `/workspace/app/backend/functions/email-templates.ts`

And restore the `SENDGRID_API_KEY` environment variable.

## Support

For Resend API documentation, visit: https://resend.com/docs

For issues or questions, contact the development team.

---

**Migration Date**: 2026-02-12  
**Migrated By**: Alex (Engineer)  
**Status**: ✅ Complete