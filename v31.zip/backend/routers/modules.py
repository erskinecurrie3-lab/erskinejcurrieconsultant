import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.modules import ModulesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/modules", tags=["modules"])


# ---------- Pydantic Schemas ----------
class ModulesData(BaseModel):
    """Entity data schema (for create/update)"""
    course_id: int
    title: str
    description: str = None
    order_index: int = None
    created_at: str = None
    updated_at: str = None


class ModulesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    course_id: Optional[int] = None
    title: Optional[str] = None
    description: Optional[str] = None
    order_index: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class ModulesResponse(BaseModel):
    """Entity response schema"""
    id: int
    course_id: int
    title: str
    description: Optional[str] = None
    order_index: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    class Config:
        from_attributes = True


class ModulesListResponse(BaseModel):
    """List response schema"""
    items: List[ModulesResponse]
    total: int
    skip: int
    limit: int


class ModulesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[ModulesData]


class ModulesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: ModulesUpdateData


class ModulesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[ModulesBatchUpdateItem]


class ModulesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=ModulesListResponse)
async def query_moduless(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query moduless with filtering, sorting, and pagination"""
    logger.debug(f"Querying moduless: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = ModulesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} moduless")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying moduless: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=ModulesListResponse)
async def query_moduless_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query moduless with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying moduless: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = ModulesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} moduless")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying moduless: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=ModulesResponse)
async def get_modules(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single modules by ID"""
    logger.debug(f"Fetching modules with id: {id}, fields={fields}")
    
    service = ModulesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Modules with id {id} not found")
            raise HTTPException(status_code=404, detail="Modules not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching modules {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=ModulesResponse, status_code=201)
async def create_modules(
    data: ModulesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new modules"""
    logger.debug(f"Creating new modules with data: {data}")
    
    service = ModulesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create modules")
        
        logger.info(f"Modules created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating modules: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating modules: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[ModulesResponse], status_code=201)
async def create_moduless_batch(
    request: ModulesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple moduless in a single request"""
    logger.debug(f"Batch creating {len(request.items)} moduless")
    
    service = ModulesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} moduless successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[ModulesResponse])
async def update_moduless_batch(
    request: ModulesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple moduless in a single request"""
    logger.debug(f"Batch updating {len(request.items)} moduless")
    
    service = ModulesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} moduless successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=ModulesResponse)
async def update_modules(
    id: int,
    data: ModulesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing modules"""
    logger.debug(f"Updating modules {id} with data: {data}")

    service = ModulesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Modules with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Modules not found")
        
        logger.info(f"Modules {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating modules {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating modules {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_moduless_batch(
    request: ModulesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple moduless by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} moduless")
    
    service = ModulesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} moduless successfully")
        return {"message": f"Successfully deleted {deleted_count} moduless", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_modules(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single modules by ID"""
    logger.debug(f"Deleting modules with id: {id}")
    
    service = ModulesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Modules with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Modules not found")
        
        logger.info(f"Modules {id} deleted successfully")
        return {"message": "Modules deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting modules {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")