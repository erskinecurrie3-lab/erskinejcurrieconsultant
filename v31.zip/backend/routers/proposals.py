import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.proposals import ProposalsService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/proposals", tags=["proposals"])


# ---------- Pydantic Schemas ----------
class ProposalsData(BaseModel):
    """Entity data schema (for create/update)"""
    lead_id: int = None
    church_id: int = None
    title: str
    content: str = None
    services: str = None
    total_amount: int = None
    status: str
    sent_at: str = None
    created_at: str
    updated_at: str = None


class ProposalsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    lead_id: Optional[int] = None
    church_id: Optional[int] = None
    title: Optional[str] = None
    content: Optional[str] = None
    services: Optional[str] = None
    total_amount: Optional[int] = None
    status: Optional[str] = None
    sent_at: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class ProposalsResponse(BaseModel):
    """Entity response schema"""
    id: int
    lead_id: Optional[int] = None
    church_id: Optional[int] = None
    title: str
    content: Optional[str] = None
    services: Optional[str] = None
    total_amount: Optional[int] = None
    status: str
    sent_at: Optional[str] = None
    user_id: str
    created_at: str
    updated_at: Optional[str] = None

    class Config:
        from_attributes = True


class ProposalsListResponse(BaseModel):
    """List response schema"""
    items: List[ProposalsResponse]
    total: int
    skip: int
    limit: int


class ProposalsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[ProposalsData]


class ProposalsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: ProposalsUpdateData


class ProposalsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[ProposalsBatchUpdateItem]


class ProposalsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=ProposalsListResponse)
async def query_proposalss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query proposalss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying proposalss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = ProposalsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} proposalss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying proposalss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=ProposalsListResponse)
async def query_proposalss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query proposalss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying proposalss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = ProposalsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} proposalss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying proposalss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=ProposalsResponse)
async def get_proposals(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single proposals by ID (user can only see their own records)"""
    logger.debug(f"Fetching proposals with id: {id}, fields={fields}")
    
    service = ProposalsService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Proposals with id {id} not found")
            raise HTTPException(status_code=404, detail="Proposals not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching proposals {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=ProposalsResponse, status_code=201)
async def create_proposals(
    data: ProposalsData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new proposals"""
    logger.debug(f"Creating new proposals with data: {data}")
    
    service = ProposalsService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create proposals")
        
        logger.info(f"Proposals created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating proposals: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating proposals: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[ProposalsResponse], status_code=201)
async def create_proposalss_batch(
    request: ProposalsBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple proposalss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} proposalss")
    
    service = ProposalsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} proposalss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[ProposalsResponse])
async def update_proposalss_batch(
    request: ProposalsBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple proposalss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} proposalss")
    
    service = ProposalsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} proposalss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=ProposalsResponse)
async def update_proposals(
    id: int,
    data: ProposalsUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing proposals (requires ownership)"""
    logger.debug(f"Updating proposals {id} with data: {data}")

    service = ProposalsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Proposals with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Proposals not found")
        
        logger.info(f"Proposals {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating proposals {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating proposals {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_proposalss_batch(
    request: ProposalsBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple proposalss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} proposalss")
    
    service = ProposalsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} proposalss successfully")
        return {"message": f"Successfully deleted {deleted_count} proposalss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_proposals(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single proposals by ID (requires ownership)"""
    logger.debug(f"Deleting proposals with id: {id}")
    
    service = ProposalsService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Proposals with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Proposals not found")
        
        logger.info(f"Proposals {id} deleted successfully")
        return {"message": "Proposals deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting proposals {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")