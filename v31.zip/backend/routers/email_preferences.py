from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from datetime import datetime

from core.database import get_db
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

router = APIRouter(prefix="/api/v1/email-preferences", tags=["email-preferences"])

class EmailPreferencesUpdate(BaseModel):
    email_on_reply: bool = True
    email_on_instructor_response: bool = True
    email_on_upvote: bool = False
    email_on_mention: bool = True
    digest_frequency: str = "instant"  # instant, hourly, daily, weekly

class EmailPreferencesResponse(BaseModel):
    id: int
    user_id: str
    email_on_reply: bool
    email_on_instructor_response: bool
    email_on_upvote: bool
    email_on_mention: bool
    digest_frequency: str
    last_digest_sent: str = None

@router.get("", response_model=EmailPreferencesResponse)
async def get_email_preferences(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get current user's email preferences"""
    from core.config import settings
    from sqlalchemy import select
    from models.user_email_preferences import UserEmailPreferences
    
    # Check if preferences exist
    stmt = select(UserEmailPreferences).where(UserEmailPreferences.user_id == current_user.id)
    result = await db.execute(stmt)
    preferences = result.scalar_one_or_none()
    
    if not preferences:
        # Create default preferences
        preferences = UserEmailPreferences(
            user_id=current_user.id,
            email_on_reply=True,
            email_on_instructor_response=True,
            email_on_upvote=False,
            email_on_mention=True,
            digest_frequency="instant",
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        db.add(preferences)
        await db.commit()
        await db.refresh(preferences)
    
    return EmailPreferencesResponse(
        id=preferences.id,
        user_id=preferences.user_id,
        email_on_reply=preferences.email_on_reply,
        email_on_instructor_response=preferences.email_on_instructor_response,
        email_on_upvote=preferences.email_on_upvote,
        email_on_mention=preferences.email_on_mention,
        digest_frequency=preferences.digest_frequency,
        last_digest_sent=preferences.last_digest_sent
    )

@router.put("", response_model=EmailPreferencesResponse)
async def update_email_preferences(
    data: EmailPreferencesUpdate,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update user's email preferences"""
    from sqlalchemy import select
    from models.user_email_preferences import UserEmailPreferences
    
    # Get existing preferences
    stmt = select(UserEmailPreferences).where(UserEmailPreferences.user_id == current_user.id)
    result = await db.execute(stmt)
    preferences = result.scalar_one_or_none()
    
    if not preferences:
        # Create new preferences
        preferences = UserEmailPreferences(
            user_id=current_user.id,
            created_at=datetime.now()
        )
        db.add(preferences)
    
    # Update preferences
    preferences.email_on_reply = data.email_on_reply
    preferences.email_on_instructor_response = data.email_on_instructor_response
    preferences.email_on_upvote = data.email_on_upvote
    preferences.email_on_mention = data.email_on_mention
    preferences.digest_frequency = data.digest_frequency
    preferences.updated_at = datetime.now()
    
    await db.commit()
    await db.refresh(preferences)
    
    return EmailPreferencesResponse(
        id=preferences.id,
        user_id=preferences.user_id,
        email_on_reply=preferences.email_on_reply,
        email_on_instructor_response=preferences.email_on_instructor_response,
        email_on_upvote=preferences.email_on_upvote,
        email_on_mention=preferences.email_on_mention,
        digest_frequency=preferences.digest_frequency,
        last_digest_sent=preferences.last_digest_sent
    )