import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.discussions import DiscussionsService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/discussions", tags=["discussions"])


# ---------- Pydantic Schemas ----------
class DiscussionsData(BaseModel):
    """Entity data schema (for create/update)"""
    course_id: int
    lesson_id: int = None
    title: str
    content: str
    is_pinned: bool = None
    is_resolved: bool = None
    upvotes: int = None
    created_at: str = None
    updated_at: str = None


class DiscussionsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    course_id: Optional[int] = None
    lesson_id: Optional[int] = None
    title: Optional[str] = None
    content: Optional[str] = None
    is_pinned: Optional[bool] = None
    is_resolved: Optional[bool] = None
    upvotes: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class DiscussionsResponse(BaseModel):
    """Entity response schema"""
    id: int
    course_id: int
    lesson_id: Optional[int] = None
    user_id: str
    title: str
    content: str
    is_pinned: Optional[bool] = None
    is_resolved: Optional[bool] = None
    upvotes: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    class Config:
        from_attributes = True


class DiscussionsListResponse(BaseModel):
    """List response schema"""
    items: List[DiscussionsResponse]
    total: int
    skip: int
    limit: int


class DiscussionsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[DiscussionsData]


class DiscussionsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: DiscussionsUpdateData


class DiscussionsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[DiscussionsBatchUpdateItem]


class DiscussionsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=DiscussionsListResponse)
async def query_discussionss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query discussionss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying discussionss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = DiscussionsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} discussionss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying discussionss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=DiscussionsListResponse)
async def query_discussionss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query discussionss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying discussionss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = DiscussionsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} discussionss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying discussionss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=DiscussionsResponse)
async def get_discussions(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single discussions by ID (user can only see their own records)"""
    logger.debug(f"Fetching discussions with id: {id}, fields={fields}")
    
    service = DiscussionsService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Discussions with id {id} not found")
            raise HTTPException(status_code=404, detail="Discussions not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching discussions {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=DiscussionsResponse, status_code=201)
async def create_discussions(
    data: DiscussionsData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new discussions"""
    logger.debug(f"Creating new discussions with data: {data}")
    
    service = DiscussionsService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create discussions")
        
        logger.info(f"Discussions created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating discussions: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating discussions: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[DiscussionsResponse], status_code=201)
async def create_discussionss_batch(
    request: DiscussionsBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple discussionss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} discussionss")
    
    service = DiscussionsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} discussionss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[DiscussionsResponse])
async def update_discussionss_batch(
    request: DiscussionsBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple discussionss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} discussionss")
    
    service = DiscussionsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} discussionss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=DiscussionsResponse)
async def update_discussions(
    id: int,
    data: DiscussionsUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing discussions (requires ownership)"""
    logger.debug(f"Updating discussions {id} with data: {data}")

    service = DiscussionsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Discussions with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Discussions not found")
        
        logger.info(f"Discussions {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating discussions {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating discussions {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_discussionss_batch(
    request: DiscussionsBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple discussionss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} discussionss")
    
    service = DiscussionsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} discussionss successfully")
        return {"message": f"Successfully deleted {deleted_count} discussionss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_discussions(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single discussions by ID (requires ownership)"""
    logger.debug(f"Deleting discussions with id: {id}")
    
    service = DiscussionsService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Discussions with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Discussions not found")
        
        logger.info(f"Discussions {id} deleted successfully")
        return {"message": "Discussions deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting discussions {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")