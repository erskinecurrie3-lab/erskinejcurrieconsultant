import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.courses import CoursesService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/courses", tags=["courses"])


# ---------- Pydantic Schemas ----------
class CoursesData(BaseModel):
    """Entity data schema (for create/update)"""
    title: str
    description: str = None
    thumbnail_url: str = None
    instructor_id: str
    category: str = None
    difficulty_level: str = None
    duration_hours: float = None
    price: float = None
    is_published: bool = None
    created_at: str = None
    updated_at: str = None


class CoursesUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    title: Optional[str] = None
    description: Optional[str] = None
    thumbnail_url: Optional[str] = None
    instructor_id: Optional[str] = None
    category: Optional[str] = None
    difficulty_level: Optional[str] = None
    duration_hours: Optional[float] = None
    price: Optional[float] = None
    is_published: Optional[bool] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class CoursesResponse(BaseModel):
    """Entity response schema"""
    id: int
    title: str
    description: Optional[str] = None
    thumbnail_url: Optional[str] = None
    instructor_id: str
    category: Optional[str] = None
    difficulty_level: Optional[str] = None
    duration_hours: Optional[float] = None
    price: Optional[float] = None
    is_published: Optional[bool] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    class Config:
        from_attributes = True


class CoursesListResponse(BaseModel):
    """List response schema"""
    items: List[CoursesResponse]
    total: int
    skip: int
    limit: int


class CoursesBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[CoursesData]


class CoursesBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: CoursesUpdateData


class CoursesBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[CoursesBatchUpdateItem]


class CoursesBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=CoursesListResponse)
async def query_coursess(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Query coursess with filtering, sorting, and pagination"""
    logger.debug(f"Querying coursess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = CoursesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
        )
        logger.debug(f"Found {result['total']} coursess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying coursess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=CoursesListResponse)
async def query_coursess_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query coursess with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying coursess: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = CoursesService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} coursess")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying coursess: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=CoursesResponse)
async def get_courses(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    """Get a single courses by ID"""
    logger.debug(f"Fetching courses with id: {id}, fields={fields}")
    
    service = CoursesService(db)
    try:
        result = await service.get_by_id(id)
        if not result:
            logger.warning(f"Courses with id {id} not found")
            raise HTTPException(status_code=404, detail="Courses not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching courses {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=CoursesResponse, status_code=201)
async def create_courses(
    data: CoursesData,
    db: AsyncSession = Depends(get_db),
):
    """Create a new courses"""
    logger.debug(f"Creating new courses with data: {data}")
    
    service = CoursesService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create courses")
        
        logger.info(f"Courses created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating courses: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating courses: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[CoursesResponse], status_code=201)
async def create_coursess_batch(
    request: CoursesBatchCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create multiple coursess in a single request"""
    logger.debug(f"Batch creating {len(request.items)} coursess")
    
    service = CoursesService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} coursess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[CoursesResponse])
async def update_coursess_batch(
    request: CoursesBatchUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update multiple coursess in a single request"""
    logger.debug(f"Batch updating {len(request.items)} coursess")
    
    service = CoursesService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} coursess successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=CoursesResponse)
async def update_courses(
    id: int,
    data: CoursesUpdateData,
    db: AsyncSession = Depends(get_db),
):
    """Update an existing courses"""
    logger.debug(f"Updating courses {id} with data: {data}")

    service = CoursesService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Courses with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Courses not found")
        
        logger.info(f"Courses {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating courses {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating courses {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_coursess_batch(
    request: CoursesBatchDeleteRequest,
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple coursess by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} coursess")
    
    service = CoursesService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} coursess successfully")
        return {"message": f"Successfully deleted {deleted_count} coursess", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_courses(
    id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete a single courses by ID"""
    logger.debug(f"Deleting courses with id: {id}")
    
    service = CoursesService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Courses with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Courses not found")
        
        logger.info(f"Courses {id} deleted successfully")
        return {"message": "Courses deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting courses {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")