import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.discussion_notifications import Discussion_notificationsService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/discussion_notifications", tags=["discussion_notifications"])


# ---------- Pydantic Schemas ----------
class Discussion_notificationsData(BaseModel):
    """Entity data schema (for create/update)"""
    discussion_id: int
    reply_id: int = None
    notification_type: str
    is_read: bool = None
    created_at: str = None


class Discussion_notificationsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    discussion_id: Optional[int] = None
    reply_id: Optional[int] = None
    notification_type: Optional[str] = None
    is_read: Optional[bool] = None
    created_at: Optional[str] = None


class Discussion_notificationsResponse(BaseModel):
    """Entity response schema"""
    id: int
    user_id: str
    discussion_id: int
    reply_id: Optional[int] = None
    notification_type: str
    is_read: Optional[bool] = None
    created_at: Optional[str] = None

    class Config:
        from_attributes = True


class Discussion_notificationsListResponse(BaseModel):
    """List response schema"""
    items: List[Discussion_notificationsResponse]
    total: int
    skip: int
    limit: int


class Discussion_notificationsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[Discussion_notificationsData]


class Discussion_notificationsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: Discussion_notificationsUpdateData


class Discussion_notificationsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[Discussion_notificationsBatchUpdateItem]


class Discussion_notificationsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=Discussion_notificationsListResponse)
async def query_discussion_notificationss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query discussion_notificationss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying discussion_notificationss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = Discussion_notificationsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} discussion_notificationss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying discussion_notificationss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=Discussion_notificationsListResponse)
async def query_discussion_notificationss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query discussion_notificationss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying discussion_notificationss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = Discussion_notificationsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} discussion_notificationss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying discussion_notificationss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=Discussion_notificationsResponse)
async def get_discussion_notifications(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single discussion_notifications by ID (user can only see their own records)"""
    logger.debug(f"Fetching discussion_notifications with id: {id}, fields={fields}")
    
    service = Discussion_notificationsService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Discussion_notifications with id {id} not found")
            raise HTTPException(status_code=404, detail="Discussion_notifications not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching discussion_notifications {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=Discussion_notificationsResponse, status_code=201)
async def create_discussion_notifications(
    data: Discussion_notificationsData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new discussion_notifications"""
    logger.debug(f"Creating new discussion_notifications with data: {data}")
    
    service = Discussion_notificationsService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create discussion_notifications")
        
        logger.info(f"Discussion_notifications created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating discussion_notifications: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating discussion_notifications: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[Discussion_notificationsResponse], status_code=201)
async def create_discussion_notificationss_batch(
    request: Discussion_notificationsBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple discussion_notificationss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} discussion_notificationss")
    
    service = Discussion_notificationsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} discussion_notificationss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[Discussion_notificationsResponse])
async def update_discussion_notificationss_batch(
    request: Discussion_notificationsBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple discussion_notificationss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} discussion_notificationss")
    
    service = Discussion_notificationsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} discussion_notificationss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=Discussion_notificationsResponse)
async def update_discussion_notifications(
    id: int,
    data: Discussion_notificationsUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing discussion_notifications (requires ownership)"""
    logger.debug(f"Updating discussion_notifications {id} with data: {data}")

    service = Discussion_notificationsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Discussion_notifications with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Discussion_notifications not found")
        
        logger.info(f"Discussion_notifications {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating discussion_notifications {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating discussion_notifications {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_discussion_notificationss_batch(
    request: Discussion_notificationsBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple discussion_notificationss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} discussion_notificationss")
    
    service = Discussion_notificationsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} discussion_notificationss successfully")
        return {"message": f"Successfully deleted {deleted_count} discussion_notificationss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_discussion_notifications(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single discussion_notifications by ID (requires ownership)"""
    logger.debug(f"Deleting discussion_notifications with id: {id}")
    
    service = Discussion_notificationsService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Discussion_notifications with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Discussion_notifications not found")
        
        logger.info(f"Discussion_notifications {id} deleted successfully")
        return {"message": "Discussion_notifications deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting discussion_notifications {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")