import json
import logging
from typing import List, Optional


from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from services.registrations import RegistrationsService
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/registrations", tags=["registrations"])


# ---------- Pydantic Schemas ----------
class RegistrationsData(BaseModel):
    """Entity data schema (for create/update)"""
    event_id: int
    church_id: int = None
    attendee_name: str
    attendee_email: str
    attendee_phone: str = None
    payment_status: str
    payment_amount: int = None
    stripe_session_id: str = None
    attended: bool = None
    created_at: str
    updated_at: str = None


class RegistrationsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    event_id: Optional[int] = None
    church_id: Optional[int] = None
    attendee_name: Optional[str] = None
    attendee_email: Optional[str] = None
    attendee_phone: Optional[str] = None
    payment_status: Optional[str] = None
    payment_amount: Optional[int] = None
    stripe_session_id: Optional[str] = None
    attended: Optional[bool] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class RegistrationsResponse(BaseModel):
    """Entity response schema"""
    id: int
    event_id: int
    church_id: Optional[int] = None
    attendee_name: str
    attendee_email: str
    attendee_phone: Optional[str] = None
    payment_status: str
    payment_amount: Optional[int] = None
    stripe_session_id: Optional[str] = None
    attended: Optional[bool] = None
    user_id: str
    created_at: str
    updated_at: Optional[str] = None

    class Config:
        from_attributes = True


class RegistrationsListResponse(BaseModel):
    """List response schema"""
    items: List[RegistrationsResponse]
    total: int
    skip: int
    limit: int


class RegistrationsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[RegistrationsData]


class RegistrationsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: RegistrationsUpdateData


class RegistrationsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[RegistrationsBatchUpdateItem]


class RegistrationsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


# ---------- Routes ----------
@router.get("", response_model=RegistrationsListResponse)
async def query_registrationss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query registrationss with filtering, sorting, and pagination (user can only see their own records)"""
    logger.debug(f"Querying registrationss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = RegistrationsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            user_id=str(current_user.id),
        )
        logger.debug(f"Found {result['total']} registrationss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying registrationss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=RegistrationsListResponse)
async def query_registrationss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    db: AsyncSession = Depends(get_db),
):
    # Query registrationss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying registrationss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = RegistrationsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort
        )
        logger.debug(f"Found {result['total']} registrationss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying registrationss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=RegistrationsResponse)
async def get_registrations(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single registrations by ID (user can only see their own records)"""
    logger.debug(f"Fetching registrations with id: {id}, fields={fields}")
    
    service = RegistrationsService(db)
    try:
        result = await service.get_by_id(id, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Registrations with id {id} not found")
            raise HTTPException(status_code=404, detail="Registrations not found")
        
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching registrations {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=RegistrationsResponse, status_code=201)
async def create_registrations(
    data: RegistrationsData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new registrations"""
    logger.debug(f"Creating new registrations with data: {data}")
    
    service = RegistrationsService(db)
    try:
        result = await service.create(data.model_dump(), user_id=str(current_user.id))
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create registrations")
        
        logger.info(f"Registrations created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating registrations: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating registrations: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[RegistrationsResponse], status_code=201)
async def create_registrationss_batch(
    request: RegistrationsBatchCreateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple registrationss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} registrationss")
    
    service = RegistrationsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump(), user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} registrationss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[RegistrationsResponse])
async def update_registrationss_batch(
    request: RegistrationsBatchUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple registrationss in a single request (requires ownership)"""
    logger.debug(f"Batch updating {len(request.items)} registrationss")
    
    service = RegistrationsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict, user_id=str(current_user.id))
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} registrationss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.put("/{id}", response_model=RegistrationsResponse)
async def update_registrations(
    id: int,
    data: RegistrationsUpdateData,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing registrations (requires ownership)"""
    logger.debug(f"Updating registrations {id} with data: {data}")

    service = RegistrationsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict, user_id=str(current_user.id))
        if not result:
            logger.warning(f"Registrations with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Registrations not found")
        
        logger.info(f"Registrations {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating registrations {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating registrations {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_registrationss_batch(
    request: RegistrationsBatchDeleteRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple registrationss by their IDs (requires ownership)"""
    logger.debug(f"Batch deleting {len(request.ids)} registrationss")
    
    service = RegistrationsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id, user_id=str(current_user.id))
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} registrationss successfully")
        return {"message": f"Successfully deleted {deleted_count} registrationss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_registrations(
    id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single registrations by ID (requires ownership)"""
    logger.debug(f"Deleting registrations with id: {id}")
    
    service = RegistrationsService(db)
    try:
        success = await service.delete(id, user_id=str(current_user.id))
        if not success:
            logger.warning(f"Registrations with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Registrations not found")
        
        logger.info(f"Registrations {id} deleted successfully")
        return {"message": "Registrations deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting registrations {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")