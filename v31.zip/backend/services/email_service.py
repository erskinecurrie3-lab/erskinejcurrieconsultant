import os
import logging
from typing import List, Dict
from resend import Resend

logger = logging.getLogger(__name__)

class EmailService:
    def __init__(self):
        api_key = os.environ.get('RESEND_API_KEY')
        if not api_key:
            logger.warning("RESEND_API_KEY not found in environment variables")
        self.resend = Resend(api_key=api_key) if api_key else None
        self.from_email = "Worship Builders Collective <noreply@worshipbuilderscollective.com>"
    
    def send_reply_notification(
        self,
        user_email: str,
        user_name: str,
        discussion_title: str,
        reply_author: str,
        reply_content: str,
        discussion_url: str
    ) -> bool:
        """Send email notification when someone replies to a discussion"""
        if not self.resend:
            logger.error("Resend client not initialized")
            return False
        
        # Truncate reply content if too long
        truncated_content = reply_content[:300] + "..." if len(reply_content) > 300 else reply_content
        
        html_content = self._get_reply_notification_template(
            user_name=user_name,
            discussion_title=discussion_title,
            reply_author=reply_author,
            reply_content=truncated_content,
            discussion_url=discussion_url
        )
        
        subject = f"New reply to your discussion: {discussion_title}"
        
        return self._send_email(user_email, subject, html_content)
    
    def send_instructor_response_notification(
        self,
        user_email: str,
        user_name: str,
        discussion_title: str,
        instructor_name: str,
        reply_content: str,
        discussion_url: str
    ) -> bool:
        """Send email notification when instructor responds"""
        if not self.resend:
            logger.error("Resend client not initialized")
            return False
        
        truncated_content = reply_content[:300] + "..." if len(reply_content) > 300 else reply_content
        
        html_content = self._get_instructor_response_template(
            user_name=user_name,
            discussion_title=discussion_title,
            instructor_name=instructor_name,
            reply_content=truncated_content,
            discussion_url=discussion_url
        )
        
        subject = f"Instructor responded to your question: {discussion_title}"
        
        return self._send_email(user_email, subject, html_content)
    
    def send_digest_email(
        self,
        user_email: str,
        user_name: str,
        notifications: List[Dict],
        digest_period: str
    ) -> bool:
        """Send digest email with multiple notifications"""
        if not self.resend:
            logger.error("Resend client not initialized")
            return False
        
        html_content = self._get_digest_template(
            user_name=user_name,
            notifications=notifications,
            digest_period=digest_period
        )
        
        subject = f"Your {digest_period} discussion digest - {len(notifications)} new notifications"
        
        return self._send_email(user_email, subject, html_content)
    
    def send_mention_notification(
        self,
        user_email: str,
        user_name: str,
        discussion_title: str,
        mentioned_by: str,
        mention_context: str,
        discussion_url: str
    ) -> bool:
        """Send email notification when user is mentioned"""
        if not self.resend:
            logger.error("Resend client not initialized")
            return False
        
        html_content = self._get_mention_notification_template(
            user_name=user_name,
            discussion_title=discussion_title,
            mentioned_by=mentioned_by,
            mention_context=mention_context,
            discussion_url=discussion_url
        )
        
        subject = f"You were mentioned in: {discussion_title}"
        
        return self._send_email(user_email, subject, html_content)
    
    def _send_email(self, to: str, subject: str, html_content: str) -> bool:
        """Send email via Resend API"""
        try:
            response = self.resend.emails.send({
                "from": self.from_email,
                "to": to,
                "subject": subject,
                "html": html_content
            })
            logger.info(f"Email sent successfully to {to}: {response}")
            return True
        except Exception as e:
            logger.error(f"Failed to send email to {to}: {str(e)}")
            return False
    
    def _get_reply_notification_template(
        self,
        user_name: str,
        discussion_title: str,
        reply_author: str,
        reply_content: str,
        discussion_url: str
    ) -> str:
        """Get HTML template for reply notification"""
        return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Reply Notification</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <!-- Header -->
                    <tr>
                        <td style="background-color: #000000; padding: 30px; text-align: center;">
                            <h1 style="color: #F4E2A3; margin: 0; font-size: 24px; font-weight: bold;">
                                WORSHIP BUILDERS COLLECTIVE
                            </h1>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="color: #000000; margin: 0 0 20px 0; font-size: 20px;">
                                Hi {user_name},
                            </h2>
                            <p style="color: #333333; font-size: 16px; line-height: 1.6; margin: 0 0 20px 0;">
                                <strong>{reply_author}</strong> replied to your discussion:
                            </p>
                            <div style="background-color: #f9f9f9; border-left: 4px solid #F4E2A3; padding: 15px; margin: 20px 0;">
                                <h3 style="color: #000000; margin: 0 0 10px 0; font-size: 18px;">
                                    {discussion_title}
                                </h3>
                                <p style="color: #666666; font-size: 14px; line-height: 1.5; margin: 0;">
                                    {reply_content}
                                </p>
                            </div>
                            <table width="100%" cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                                <tr>
                                    <td align="center">
                                        <a href="{discussion_url}" style="display: inline-block; background-color: #F4E2A3; color: #000000; text-decoration: none; padding: 14px 30px; border-radius: 4px; font-weight: bold; font-size: 16px;">
                                            View Discussion
                                        </a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9f9f9; padding: 20px 30px; text-align: center; border-top: 1px solid #e0e0e0;">
                            <p style="color: #999999; font-size: 12px; margin: 0 0 10px 0;">
                                You're receiving this email because you have notifications enabled for your discussions.
                            </p>
                            <p style="color: #999999; font-size: 12px; margin: 0;">
                                <a href="{discussion_url.split('/learn')[0]}/settings" style="color: #666666; text-decoration: underline;">Manage email preferences</a> | 
                                <a href="#" style="color: #666666; text-decoration: underline;">Unsubscribe</a>
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        """
    
    def _get_instructor_response_template(
        self,
        user_name: str,
        discussion_title: str,
        instructor_name: str,
        reply_content: str,
        discussion_url: str
    ) -> str:
        """Get HTML template for instructor response notification"""
        return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructor Response</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <!-- Header -->
                    <tr>
                        <td style="background-color: #000000; padding: 30px; text-align: center;">
                            <h1 style="color: #F4E2A3; margin: 0; font-size: 24px; font-weight: bold;">
                                WORSHIP BUILDERS COLLECTIVE
                            </h1>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <div style="background-color: #e3f2fd; border-left: 4px solid #2196F3; padding: 15px; margin: 0 0 20px 0;">
                                <p style="color: #1976D2; font-size: 14px; font-weight: bold; margin: 0;">
                                    🎓 INSTRUCTOR RESPONSE
                                </p>
                            </div>
                            <h2 style="color: #000000; margin: 0 0 20px 0; font-size: 20px;">
                                Hi {user_name},
                            </h2>
                            <p style="color: #333333; font-size: 16px; line-height: 1.6; margin: 0 0 20px 0;">
                                Great news! <strong>{instructor_name}</strong> (Instructor) responded to your question:
                            </p>
                            <div style="background-color: #f9f9f9; border-left: 4px solid #F4E2A3; padding: 15px; margin: 20px 0;">
                                <h3 style="color: #000000; margin: 0 0 10px 0; font-size: 18px;">
                                    {discussion_title}
                                </h3>
                                <p style="color: #666666; font-size: 14px; line-height: 1.5; margin: 0;">
                                    {reply_content}
                                </p>
                            </div>
                            <table width="100%" cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                                <tr>
                                    <td align="center">
                                        <a href="{discussion_url}" style="display: inline-block; background-color: #F4E2A3; color: #000000; text-decoration: none; padding: 14px 30px; border-radius: 4px; font-weight: bold; font-size: 16px;">
                                            View Response
                                        </a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9f9f9; padding: 20px 30px; text-align: center; border-top: 1px solid #e0e0e0;">
                            <p style="color: #999999; font-size: 12px; margin: 0 0 10px 0;">
                                You're receiving this email because an instructor responded to your question.
                            </p>
                            <p style="color: #999999; font-size: 12px; margin: 0;">
                                <a href="{discussion_url.split('/learn')[0]}/settings" style="color: #666666; text-decoration: underline;">Manage email preferences</a> | 
                                <a href="#" style="color: #666666; text-decoration: underline;">Unsubscribe</a>
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        """
    
    def _get_digest_template(
        self,
        user_name: str,
        notifications: List[Dict],
        digest_period: str
    ) -> str:
        """Get HTML template for digest email"""
        # Group notifications by type
        instructor_responses = [n for n in notifications if n.get('type') == 'instructor_response']
        replies = [n for n in notifications if n.get('type') == 'new_reply']
        upvotes = [n for n in notifications if n.get('type') == 'upvote']
        mentions = [n for n in notifications if n.get('type') == 'mention']
        
        notifications_html = ""
        
        if instructor_responses:
            notifications_html += f"""
            <h3 style="color: #000000; font-size: 18px; margin: 20px 0 10px 0;">
                🎓 Instructor Responses ({len(instructor_responses)})
            </h3>
            """
            for notif in instructor_responses:
                notifications_html += f"""
                <div style="background-color: #e3f2fd; border-left: 4px solid #2196F3; padding: 12px; margin: 10px 0;">
                    <p style="color: #000000; font-size: 14px; margin: 0 0 5px 0; font-weight: bold;">
                        {notif.get('discussion_title', 'Discussion')}
                    </p>
                    <p style="color: #666666; font-size: 13px; margin: 0;">
                        {notif.get('instructor_name', 'Instructor')} responded to your question
                    </p>
                </div>
                """
        
        if replies:
            notifications_html += f"""
            <h3 style="color: #000000; font-size: 18px; margin: 20px 0 10px 0;">
                💬 New Replies ({len(replies)})
            </h3>
            """
            for notif in replies:
                notifications_html += f"""
                <div style="background-color: #f9f9f9; border-left: 4px solid #F4E2A3; padding: 12px; margin: 10px 0;">
                    <p style="color: #000000; font-size: 14px; margin: 0 0 5px 0; font-weight: bold;">
                        {notif.get('discussion_title', 'Discussion')}
                    </p>
                    <p style="color: #666666; font-size: 13px; margin: 0;">
                        {notif.get('reply_author', 'Someone')} replied to your discussion
                    </p>
                </div>
                """
        
        if upvotes:
            notifications_html += f"""
            <h3 style="color: #000000; font-size: 18px; margin: 20px 0 10px 0;">
                👍 Upvotes ({len(upvotes)})
            </h3>
            <p style="color: #666666; font-size: 14px; margin: 0;">
                Your posts received {len(upvotes)} new upvotes
            </p>
            """
        
        if mentions:
            notifications_html += f"""
            <h3 style="color: #000000; font-size: 18px; margin: 20px 0 10px 0;">
                @ Mentions ({len(mentions)})
            </h3>
            """
            for notif in mentions:
                notifications_html += f"""
                <div style="background-color: #fff3e0; border-left: 4px solid #ff9800; padding: 12px; margin: 10px 0;">
                    <p style="color: #000000; font-size: 14px; margin: 0 0 5px 0; font-weight: bold;">
                        {notif.get('discussion_title', 'Discussion')}
                    </p>
                    <p style="color: #666666; font-size: 13px; margin: 0;">
                        {notif.get('mentioned_by', 'Someone')} mentioned you
                    </p>
                </div>
                """
        
        return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discussion Digest</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <!-- Header -->
                    <tr>
                        <td style="background-color: #000000; padding: 30px; text-align: center;">
                            <h1 style="color: #F4E2A3; margin: 0; font-size: 24px; font-weight: bold;">
                                WORSHIP BUILDERS COLLECTIVE
                            </h1>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="color: #000000; margin: 0 0 10px 0; font-size: 20px;">
                                Hi {user_name},
                            </h2>
                            <p style="color: #333333; font-size: 16px; line-height: 1.6; margin: 0 0 20px 0;">
                                Here's your {digest_period} discussion digest with <strong>{len(notifications)} new notifications</strong>:
                            </p>
                            
                            {notifications_html}
                            
                            <table width="100%" cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                                <tr>
                                    <td align="center">
                                        <a href="https://yourapp.com/lms/courses" style="display: inline-block; background-color: #F4E2A3; color: #000000; text-decoration: none; padding: 14px 30px; border-radius: 4px; font-weight: bold; font-size: 16px;">
                                            View All Discussions
                                        </a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9f9f9; padding: 20px 30px; text-align: center; border-top: 1px solid #e0e0e0;">
                            <p style="color: #999999; font-size: 12px; margin: 0 0 10px 0;">
                                You're receiving this {digest_period} digest based on your email preferences.
                            </p>
                            <p style="color: #999999; font-size: 12px; margin: 0;">
                                <a href="https://yourapp.com/lms/settings" style="color: #666666; text-decoration: underline;">Manage email preferences</a> | 
                                <a href="#" style="color: #666666; text-decoration: underline;">Unsubscribe</a>
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        """
    
    def _get_mention_notification_template(
        self,
        user_name: str,
        discussion_title: str,
        mentioned_by: str,
        mention_context: str,
        discussion_url: str
    ) -> str:
        """Get HTML template for mention notification"""
        return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mention Notification</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f5f5;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <!-- Header -->
                    <tr>
                        <td style="background-color: #000000; padding: 30px; text-align: center;">
                            <h1 style="color: #F4E2A3; margin: 0; font-size: 24px; font-weight: bold;">
                                WORSHIP BUILDERS COLLECTIVE
                            </h1>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="color: #000000; margin: 0 0 20px 0; font-size: 20px;">
                                Hi {user_name},
                            </h2>
                            <p style="color: #333333; font-size: 16px; line-height: 1.6; margin: 0 0 20px 0;">
                                <strong>{mentioned_by}</strong> mentioned you in a discussion:
                            </p>
                            <div style="background-color: #fff3e0; border-left: 4px solid #ff9800; padding: 15px; margin: 20px 0;">
                                <h3 style="color: #000000; margin: 0 0 10px 0; font-size: 18px;">
                                    {discussion_title}
                                </h3>
                                <p style="color: #666666; font-size: 14px; line-height: 1.5; margin: 0;">
                                    {mention_context}
                                </p>
                            </div>
                            <table width="100%" cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                                <tr>
                                    <td align="center">
                                        <a href="{discussion_url}" style="display: inline-block; background-color: #F4E2A3; color: #000000; text-decoration: none; padding: 14px 30px; border-radius: 4px; font-weight: bold; font-size: 16px;">
                                            View Discussion
                                        </a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9f9f9; padding: 20px 30px; text-align: center; border-top: 1px solid #e0e0e0;">
                            <p style="color: #999999; font-size: 12px; margin: 0 0 10px 0;">
                                You're receiving this email because someone mentioned you in a discussion.
                            </p>
                            <p style="color: #999999; font-size: 12px; margin: 0;">
                                <a href="{discussion_url.split('/learn')[0]}/settings" style="color: #666666; text-decoration: underline;">Manage email preferences</a> | 
                                <a href="#" style="color: #666666; text-decoration: underline;">Unsubscribe</a>
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        """

# Singleton instance
email_service = EmailService()