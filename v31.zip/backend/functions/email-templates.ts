// Email templates for automated workflows
// These templates use Resend API for email delivery

export const emailTemplates = {
  // Welcome email for new leads
  newLeadWelcome: {
    subject: 'Welcome to Erskine J Currie Ministry Consulting',
    templateId: 'new_lead_welcome',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #000000; color: #ffffff; padding: 40px 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #F4E2A3; margin: 0;">Welcome to Our Ministry Family</h1>
        </div>
        
        <div style="background-color: #1a1a1a; padding: 30px; border-radius: 8px; margin-bottom: 20px;">
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Dear {{name}},
          </p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Thank you for your interest in our ministry consulting services. We're excited to partner with {{church_name}} on your journey toward greater kingdom impact.
          </p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Over the next few days, you'll receive valuable resources and insights to help you:
          </p>
          
          <ul style="font-size: 16px; line-height: 1.8; margin-bottom: 20px;">
            <li>Assess your current ministry health</li>
            <li>Identify growth opportunities</li>
            <li>Build stronger leadership teams</li>
            <li>Create sustainable systems</li>
          </ul>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{booking_url}}" style="background-color: #F4E2A3; color: #000000; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
              Schedule Your Free Consultation
            </a>
          </div>
        </div>
        
        <div style="text-align: center; padding-top: 20px; border-top: 1px solid #333333; color: #999999; font-size: 14px;">
          <p>Erskine J Currie Ministry Consulting</p>
          <p>Building Healthy, Growing Churches</p>
        </div>
      </div>
    `
  },

  // Event reminder email
  eventReminder: {
    subject: 'Reminder: {{event_title}} is coming up!',
    templateId: 'event_reminder',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 40px 20px;">
        <div style="background-color: #000000; color: #ffffff; padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="color: #F4E2A3; margin: 0;">Event Reminder</h1>
        </div>
        
        <div style="padding: 30px; background-color: #f9f9f9; border-radius: 0 0 8px 8px;">
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Hi {{name}},
          </p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            This is a friendly reminder that <strong>{{event_title}}</strong> is coming up soon!
          </p>
          
          <div style="background-color: #ffffff; padding: 20px; border-left: 4px solid #F4E2A3; margin: 20px 0;">
            <p style="margin: 5px 0;"><strong>Date:</strong> {{event_date}}</p>
            <p style="margin: 5px 0;"><strong>Time:</strong> {{event_time}}</p>
            <p style="margin: 5px 0;"><strong>Location:</strong> {{event_location}}</p>
          </div>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            We're looking forward to seeing you there! If you have any questions, please don't hesitate to reach out.
          </p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{event_url}}" style="background-color: #F4E2A3; color: #000000; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
              View Event Details
            </a>
          </div>
        </div>
      </div>
    `
  },

  // Weekly report email
  weeklyReport: {
    subject: 'Your Weekly Ministry Consulting Report',
    templateId: 'weekly_report',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 40px 20px;">
        <div style="background-color: #000000; color: #ffffff; padding: 30px; text-align: center;">
          <h1 style="color: #F4E2A3; margin: 0;">Weekly Report</h1>
          <p style="color: #cccccc; margin-top: 10px;">{{date_range}}</p>
        </div>
        
        <div style="padding: 30px; background-color: #f9f9f9;">
          <h2 style="color: #000000; border-bottom: 2px solid #F4E2A3; padding-bottom: 10px;">Key Metrics</h2>
          
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0;">
            <div style="background-color: #ffffff; padding: 20px; border-radius: 8px; text-align: center;">
              <p style="color: #666666; margin: 0; font-size: 14px;">New Leads</p>
              <p style="color: #000000; margin: 10px 0 0 0; font-size: 32px; font-weight: bold;">{{new_leads}}</p>
            </div>
            <div style="background-color: #ffffff; padding: 20px; border-radius: 8px; text-align: center;">
              <p style="color: #666666; margin: 0; font-size: 14px;">Active Clients</p>
              <p style="color: #000000; margin: 10px 0 0 0; font-size: 32px; font-weight: bold;">{{active_clients}}</p>
            </div>
            <div style="background-color: #ffffff; padding: 20px; border-radius: 8px; text-align: center;">
              <p style="color: #666666; margin: 0; font-size: 14px;">Revenue</p>
              <p style="color: #F4E2A3; margin: 10px 0 0 0; font-size: 32px; font-weight: bold;">\\${{revenue}}</p>
            </div>
            <div style="background-color: #ffffff; padding: 20px; border-radius: 8px; text-align: center;">
              <p style="color: #666666; margin: 0; font-size: 14px;">Conversion Rate</p>
              <p style="color: #000000; margin: 10px 0 0 0; font-size: 32px; font-weight: bold;">{{conversion_rate}}%</p>
            </div>
          </div>
          
          <h2 style="color: #000000; border-bottom: 2px solid #F4E2A3; padding-bottom: 10px; margin-top: 30px;">Recent Activity</h2>
          <div style="background-color: #ffffff; padding: 20px; border-radius: 8px; margin-top: 15px;">
            {{activity_list}}
          </div>
        </div>
      </div>
    `
  },

  // Client welcome email
  clientWelcome: {
    subject: 'Welcome to Your Ministry Consulting Journey',
    templateId: 'client_welcome',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #000000; color: #ffffff; padding: 40px 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #F4E2A3; margin: 0;">Welcome to the Team!</h1>
        </div>
        
        <div style="background-color: #1a1a1a; padding: 30px; border-radius: 8px; margin-bottom: 20px;">
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Dear {{name}},
          </p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Welcome to Erskine J Currie Ministry Consulting! We're thrilled to begin this partnership with {{church_name}}.
          </p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Your client portal is now active. Here you can:
          </p>
          
          <ul style="font-size: 16px; line-height: 1.8; margin-bottom: 20px;">
            <li>Track project progress</li>
            <li>View assessment results</li>
            <li>Access shared documents</li>
            <li>Message your consultant</li>
          </ul>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{portal_url}}" style="background-color: #F4E2A3; color: #000000; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
              Access Your Portal
            </a>
          </div>
          
          <p style="font-size: 16px; line-height: 1.6; margin-top: 30px;">
            Your dedicated consultant will reach out within 24 hours to schedule your kickoff meeting.
          </p>
        </div>
      </div>
    `
  },

  // Post-event feedback
  postEventFeedback: {
    subject: 'How was {{event_title}}? We\'d love your feedback',
    templateId: 'post_event_feedback',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 40px 20px;">
        <div style="background-color: #000000; color: #ffffff; padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="color: #F4E2A3; margin: 0;">Thank You for Attending!</h1>
        </div>
        
        <div style="padding: 30px; background-color: #f9f9f9; border-radius: 0 0 8px 8px;">
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Hi {{name}},
          </p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Thank you for attending <strong>{{event_title}}</strong>! We hope you found it valuable and inspiring.
          </p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Your feedback helps us improve future events and better serve ministry leaders like you. Would you take 2 minutes to share your thoughts?
          </p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{feedback_url}}" style="background-color: #F4E2A3; color: #000000; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
              Share Your Feedback
            </a>
          </div>
          
          <div style="background-color: #ffffff; padding: 20px; border-left: 4px solid #F4E2A3; margin: 20px 0;">
            <p style="margin: 0; font-weight: bold;">Event Resources</p>
            <p style="margin: 10px 0 0 0;">Access slides, handouts, and additional materials from the event:</p>
            <a href="{{resources_url}}" style="color: #F4E2A3; text-decoration: none;">View Resources →</a>
          </div>
        </div>
      </div>
    `
  },

  // Abandoned booking reminder
  abandonedBooking: {
    subject: 'Complete Your Consultation Booking',
    templateId: 'abandoned_booking',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 40px 20px;">
        <div style="background-color: #000000; color: #ffffff; padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="color: #F4E2A3; margin: 0;">Don't Miss Your Free Consultation</h1>
        </div>
        
        <div style="padding: 30px; background-color: #f9f9f9; border-radius: 0 0 8px 8px;">
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Hi {{name}},
          </p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            We noticed you started booking a consultation but didn't complete the process. We'd love to help {{church_name}} achieve its ministry goals!
          </p>
          
          <div style="background-color: #ffffff; padding: 20px; border-left: 4px solid #F4E2A3; margin: 20px 0;">
            <p style="margin: 0; font-weight: bold;">Your Free Consultation Includes:</p>
            <ul style="margin: 10px 0 0 0; padding-left: 20px;">
              <li>60-minute strategy session</li>
              <li>Ministry health assessment</li>
              <li>Customized growth recommendations</li>
              <li>No obligation to continue</li>
            </ul>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{booking_url}}" style="background-color: #F4E2A3; color: #000000; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
              Complete Your Booking
            </a>
          </div>
          
          <p style="font-size: 14px; line-height: 1.6; color: #666666; text-align: center; margin-top: 20px;">
            Questions? Reply to this email or call us at (555) 123-4567
          </p>
        </div>
      </div>
    `
  },

  // Lead nurture sequence - Day 3
  leadNurture3: {
    subject: '3 Signs Your Church Needs Strategic Consulting',
    templateId: 'lead_nurture_3',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 40px 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #000000; margin: 0;">Is Your Church Ready for Growth?</h1>
        </div>
        
        <div style="padding: 30px; background-color: #f9f9f9; border-radius: 8px;">
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Hi {{name}},
          </p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            Many church leaders struggle to know when it's time to seek outside help. Here are 3 clear signs:
          </p>
          
          <div style="background-color: #ffffff; padding: 20px; border-left: 4px solid #F4E2A3; margin: 20px 0;">
            <h3 style="color: #000000; margin-top: 0;">1. Plateau or Decline</h3>
            <p style="margin: 0;">Your attendance or engagement has been flat or declining for 6+ months.</p>
          </div>
          
          <div style="background-color: #ffffff; padding: 20px; border-left: 4px solid #F4E2A3; margin: 20px 0;">
            <h3 style="color: #000000; margin-top: 0;">2. Leadership Burnout</h3>
            <p style="margin: 0;">Your team is exhausted, and key volunteers are hard to recruit or retain.</p>
          </div>
          
          <div style="background-color: #ffffff; padding: 20px; border-left: 4px solid #F4E2A3; margin: 20px 0;">
            <h3 style="color: #000000; margin-top: 0;">3. Unclear Vision</h3>
            <p style="margin: 0;">You're not sure what success looks like or how to get there.</p>
          </div>
          
          <p style="font-size: 16px; line-height: 1.6; margin-top: 30px;">
            Sound familiar? Let's talk about how strategic consulting can help {{church_name}} break through.
          </p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="{{booking_url}}" style="background-color: #F4E2A3; color: #000000; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
              Schedule Free Consultation
            </a>
          </div>
        </div>
      </div>
    `
  }
};

// Helper function to replace template variables
export function renderTemplate(template: any, data: Record<string, any>): string {
  let html = template.html;
  let subject = template.subject;
  
  Object.keys(data).forEach(key => {
    const regex = new RegExp(`{{${key}}}`, 'g');
    html = html.replace(regex, data[key] || '');
    subject = subject.replace(regex, data[key] || '');
  });
  
  return html;
}

export function renderSubject(template: any, data: Record<string, any>): string {
  let subject = template.subject;
  
  Object.keys(data).forEach(key => {
    const regex = new RegExp(`{{${key}}}`, 'g');
    subject = subject.replace(regex, data[key] || '');
  });
  
  return subject;
}