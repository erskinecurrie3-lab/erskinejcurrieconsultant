/**
 * Email Automation Functions
 * Handles automated email sequences via Resend API
 */

import os from 'os';

// Resend configuration
const RESEND_API_KEY = process.env.RESEND_API_KEY || '';
const FROM_EMAIL = 'hello@erskinecurrie.com';
const FROM_NAME = 'Erskine J Currie Ministries';

interface EmailTemplate {
  subject: string;
  htmlContent: string;
  textContent: string;
}

/**
 * Send email via Resend API
 */
async function sendEmail(
  to: string,
  subject: string,
  htmlContent: string,
  textContent: string
): Promise<boolean> {
  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: `${FROM_NAME} <${FROM_EMAIL}>`,
        to: [to],
        subject,
        html: htmlContent,
        text: textContent,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('Resend API error:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Resend email failed:', error);
    return false;
  }
}

/**
 * Generate branded email HTML template
 */
function getBrandedTemplate(content: string): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #000; color: #F4E2A3; padding: 30px 20px; text-align: center; }
        .header h1 { margin: 0; font-size: 24px; }
        .content { background-color: #fff; padding: 30px 20px; }
        .button { display: inline-block; background-color: #F4E2A3; color: #000; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; margin: 20px 0; }
        .footer { background-color: #f5f5f5; padding: 20px; text-align: center; font-size: 12px; color: #666; }
        .divider { height: 2px; background-color: #F4E2A3; margin: 20px 0; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Erskine J Currie Ministries</h1>
        </div>
        <div class="content">
          ${content}
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} Erskine J Currie Ministries. All rights reserved.</p>
          <p>You're receiving this email because you signed up for our services or resources.</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

/**
 * New Lead Welcome Email (Day 0)
 */
export async function sendNewLeadWelcome(
  email: string,
  name: string
): Promise<boolean> {
  const content = `
    <h2>Welcome, ${name}!</h2>
    <p>Thank you for your interest in Erskine J Currie Ministries. We're excited to connect with you and support your ministry journey.</p>
    <div class="divider"></div>
    <h3>What's Next?</h3>
    <ul>
      <li>Explore our <strong>free resources</strong> designed for church leaders</li>
      <li>Schedule a <strong>complimentary consultation</strong> to discuss your needs</li>
      <li>Take our <strong>Church Health Assessment</strong> to identify growth opportunities</li>
    </ul>
    <a href="https://erskinecurrie.com/booking" class="button">Schedule a Consultation</a>
    <p>In the meantime, feel free to browse our resource library and upcoming events. We're here to help you build a thriving ministry.</p>
    <p>Blessings,<br><strong>Erskine J Currie</strong></p>
  `;

  const htmlContent = getBrandedTemplate(content);
  const textContent = `Welcome, ${name}! Thank you for your interest in Erskine J Currie Ministries. Schedule a consultation at https://erskinecurrie.com/booking`;

  return sendEmail(email, 'Welcome to Erskine J Currie Ministries', htmlContent, textContent);
}

/**
 * Lead Follow-up Email (Day 3)
 */
export async function sendLeadFollowUp(
  email: string,
  name: string,
  leadStage: string
): Promise<boolean> {
  const content = `
    <h2>Hi ${name},</h2>
    <p>I wanted to follow up and see how we can best support your ministry. Whether you're planting a church, building your worship team, or seeking strategic guidance, we're here to help.</p>
    <div class="divider"></div>
    <h3>Popular Services:</h3>
    <ul>
      <li><strong>Church Planting Coaching</strong> - Launch with confidence</li>
      <li><strong>Worship Team Building</strong> - Develop excellence in worship</li>
      <li><strong>Strategic Consulting</strong> - Grow your impact</li>
    </ul>
    <a href="https://erskinecurrie.com/services" class="button">Explore Services</a>
    <p>Have questions? Simply reply to this email or schedule a call at your convenience.</p>
    <p>Blessings,<br><strong>Erskine J Currie</strong></p>
  `;

  const htmlContent = getBrandedTemplate(content);
  const textContent = `Hi ${name}, Following up to see how we can support your ministry. View our services at https://erskinecurrie.com/services`;

  return sendEmail(email, 'How Can We Support Your Ministry?', htmlContent, textContent);
}

/**
 * Event Registration Confirmation
 */
export async function sendEventConfirmation(
  email: string,
  name: string,
  eventTitle: string,
  eventDate: string,
  eventLocation: string
): Promise<boolean> {
  const content = `
    <h2>Registration Confirmed!</h2>
    <p>Hi ${name},</p>
    <p>You're all set for <strong>${eventTitle}</strong>. We're excited to see you there!</p>
    <div class="divider"></div>
    <h3>Event Details:</h3>
    <ul>
      <li><strong>Event:</strong> ${eventTitle}</li>
      <li><strong>Date:</strong> ${eventDate}</li>
      <li><strong>Location:</strong> ${eventLocation}</li>
    </ul>
    <p>You'll receive a reminder email 24 hours before the event with any last-minute details.</p>
    <a href="https://erskinecurrie.com/events" class="button">View Event Details</a>
    <p>See you soon!<br><strong>Erskine J Currie</strong></p>
  `;

  const htmlContent = getBrandedTemplate(content);
  const textContent = `Registration confirmed for ${eventTitle} on ${eventDate}. Location: ${eventLocation}`;

  return sendEmail(email, `Confirmed: ${eventTitle}`, htmlContent, textContent);
}

/**
 * Event Reminder (24 hours before)
 */
export async function sendEventReminder(
  email: string,
  name: string,
  eventTitle: string,
  eventDate: string,
  eventLocation: string
): Promise<boolean> {
  const content = `
    <h2>Reminder: Event Tomorrow!</h2>
    <p>Hi ${name},</p>
    <p>This is a friendly reminder that <strong>${eventTitle}</strong> is tomorrow. We're looking forward to seeing you!</p>
    <div class="divider"></div>
    <h3>Event Details:</h3>
    <ul>
      <li><strong>Event:</strong> ${eventTitle}</li>
      <li><strong>Date:</strong> ${eventDate}</li>
      <li><strong>Location:</strong> ${eventLocation}</li>
    </ul>
    <p><strong>What to Bring:</strong> Notebook, Bible, and an open heart ready to learn and grow.</p>
    <a href="https://erskinecurrie.com/events" class="button">View Event Details</a>
    <p>See you tomorrow!<br><strong>Erskine J Currie</strong></p>
  `;

  const htmlContent = getBrandedTemplate(content);
  const textContent = `Reminder: ${eventTitle} is tomorrow (${eventDate}) at ${eventLocation}`;

  return sendEmail(email, `Tomorrow: ${eventTitle}`, htmlContent, textContent);
}

/**
 * Post-Event Feedback Request
 */
export async function sendPostEventFeedback(
  email: string,
  name: string,
  eventTitle: string
): Promise<boolean> {
  const content = `
    <h2>Thank You for Attending!</h2>
    <p>Hi ${name},</p>
    <p>Thank you for joining us at <strong>${eventTitle}</strong>. We hope it was valuable for your ministry journey.</p>
    <div class="divider"></div>
    <h3>We'd Love Your Feedback</h3>
    <p>Your input helps us improve and serve church leaders better. Would you take 2 minutes to share your thoughts?</p>
    <a href="https://erskinecurrie.com/feedback" class="button">Share Feedback</a>
    <p>As a thank you, we'll send you a free resource on leadership development.</p>
    <p>Blessings,<br><strong>Erskine J Currie</strong></p>
  `;

  const htmlContent = getBrandedTemplate(content);
  const textContent = `Thank you for attending ${eventTitle}! Share your feedback at https://erskinecurrie.com/feedback`;

  return sendEmail(email, `Thank You for Attending ${eventTitle}`, htmlContent, textContent);
}

/**
 * New Client Welcome Series (Day 0)
 */
export async function sendClientWelcome(
  email: string,
  name: string,
  churchName: string
): Promise<boolean> {
  const content = `
    <h2>Welcome to the Family, ${name}!</h2>
    <p>We're thrilled to partner with <strong>${churchName}</strong> on this journey. Your commitment to excellence in ministry inspires us.</p>
    <div class="divider"></div>
    <h3>Getting Started:</h3>
    <ul>
      <li>Access your <strong>Client Portal</strong> to view projects and resources</li>
      <li>Review your <strong>customized roadmap</strong> for the next 90 days</li>
      <li>Schedule your <strong>kickoff call</strong> to align on goals</li>
    </ul>
    <a href="https://erskinecurrie.com/portal/dashboard" class="button">Access Client Portal</a>
    <p>You'll receive weekly updates on progress and next steps. We're committed to your success!</p>
    <p>Blessings,<br><strong>Erskine J Currie</strong></p>
  `;

  const htmlContent = getBrandedTemplate(content);
  const textContent = `Welcome ${name}! Access your client portal at https://erskinecurrie.com/portal/dashboard`;

  return sendEmail(email, 'Welcome to Erskine J Currie Ministries', htmlContent, textContent);
}

/**
 * Resource Download Confirmation
 */
export async function sendResourceDownload(
  email: string,
  name: string,
  resourceTitle: string
): Promise<boolean> {
  const content = `
    <h2>Your Resource is Ready!</h2>
    <p>Hi ${name},</p>
    <p>Thank you for downloading <strong>${resourceTitle}</strong>. We hope it serves you well in your ministry.</p>
    <div class="divider"></div>
    <h3>More Free Resources:</h3>
    <p>Explore our complete library of guides, templates, and tools designed for church leaders like you.</p>
    <a href="https://erskinecurrie.com/resources" class="button">Browse Resources</a>
    <p>Need personalized guidance? Schedule a free consultation to discuss your specific challenges.</p>
    <p>Blessings,<br><strong>Erskine J Currie</strong></p>
  `;

  const htmlContent = getBrandedTemplate(content);
  const textContent = `Your resource "${resourceTitle}" is ready! Browse more at https://erskinecurrie.com/resources`;

  return sendEmail(email, `Your Resource: ${resourceTitle}`, htmlContent, textContent);
}

/**
 * Abandoned Booking Reminder
 */
export async function sendAbandonedBookingReminder(
  email: string,
  name: string
): Promise<boolean> {
  const content = `
    <h2>Complete Your Booking</h2>
    <p>Hi ${name},</p>
    <p>We noticed you started booking a consultation but didn't finish. We'd love to connect with you!</p>
    <div class="divider"></div>
    <h3>Why Schedule a Consultation?</h3>
    <ul>
      <li>Get personalized advice for your ministry challenges</li>
      <li>Explore how we can support your growth</li>
      <li>No obligation - just a friendly conversation</li>
    </ul>
    <a href="https://erskinecurrie.com/booking" class="button">Complete Booking</a>
    <p>Have questions? Reply to this email and we'll get back to you quickly.</p>
    <p>Blessings,<br><strong>Erskine J Currie</strong></p>
  `;

  const htmlContent = getBrandedTemplate(content);
  const textContent = `Complete your consultation booking at https://erskinecurrie.com/booking`;

  return sendEmail(email, 'Complete Your Consultation Booking', htmlContent, textContent);
}

/**
 * Weekly Report Email
 */
export async function sendWeeklyReport(
  email: string,
  reportData: {
    newLeads: number;
    activeClients: number;
    upcomingEvents: number;
    revenueThisWeek: number;
  }
): Promise<boolean> {
  const content = `
    <h2>Weekly Operations Summary</h2>
    <p>Here's your weekly snapshot of key metrics and activities.</p>
    <div class="divider"></div>
    <h3>Key Metrics:</h3>
    <ul>
      <li><strong>New Leads:</strong> ${reportData.newLeads}</li>
      <li><strong>Active Clients:</strong> ${reportData.activeClients}</li>
      <li><strong>Upcoming Events:</strong> ${reportData.upcomingEvents}</li>
      <li><strong>Revenue This Week:</strong> $${reportData.revenueThisWeek.toLocaleString()}</li>
    </ul>
    <a href="https://erskinecurrie.com/admin/dashboard" class="button">View Full Dashboard</a>
    <p>This report is automatically generated every Monday at 8:00 AM.</p>
  `;

  const htmlContent = getBrandedTemplate(content);
  const textContent = `Weekly Report: ${reportData.newLeads} new leads, ${reportData.activeClients} active clients, $${reportData.revenueThisWeek} revenue`;

  return sendEmail(email, 'Weekly Operations Report', htmlContent, textContent);
}

export default {
  sendNewLeadWelcome,
  sendLeadFollowUp,
  sendEventConfirmation,
  sendEventReminder,
  sendPostEventFeedback,
  sendClientWelcome,
  sendResourceDownload,
  sendAbandonedBookingReminder,
  sendWeeklyReport,
};