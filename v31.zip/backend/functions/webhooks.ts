/**
 * Webhook Handlers
 * Real-time event triggers for automation
 */

import {
  sendNewLeadWelcome,
  sendLeadFollowUp,
  sendEventConfirmation,
  sendClientWelcome,
  sendResourceDownload,
} from './email-automation';

/**
 * Webhook: New Lead Created
 * Triggered when a new lead is added to the CRM
 */
export async function onNewLeadCreated(leadData: {
  id: string;
  name: string;
  email: string;
  church_name: string;
  source: string;
  stage: string;
}) {
  console.log(`New lead webhook triggered: ${leadData.email}`);

  try {
    // Send welcome email immediately
    await sendNewLeadWelcome(leadData.email, leadData.name);

    // Schedule follow-up email for 3 days later (would use a job queue in production)
    // await scheduleEmail({
    //   type: 'lead_followup',
    //   to: leadData.email,
    //   data: leadData,
    //   sendAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000)
    // });

    // Create initial task for sales follow-up
    // await db.tasks.create({
    //   data: {
    //     title: `Follow up with ${leadData.name}`,
    //     description: `New lead from ${leadData.source}. Church: ${leadData.church_name}`,
    //     assigned_to: 'admin@erskinecurrie.com',
    //     due_date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    //     status: 'pending',
    //     priority: 'high'
    //   }
    // });

    console.log('New lead automation completed successfully');
    return { success: true, message: 'Lead welcome email sent' };
  } catch (error) {
    console.error('New lead webhook failed:', error);
    return { success: false, error: String(error) };
  }
}

/**
 * Webhook: Lead Stage Changed
 * Triggered when a lead moves to a different stage in the pipeline
 */
export async function onLeadStageChanged(leadData: {
  id: string;
  name: string;
  email: string;
  old_stage: string;
  new_stage: string;
}) {
  console.log(`Lead stage changed: ${leadData.email} (${leadData.old_stage} → ${leadData.new_stage})`);

  try {
    // Send appropriate email based on new stage
    if (leadData.new_stage === 'consultation') {
      // Send consultation prep email
      // await sendConsultationPrepEmail(leadData.email, leadData.name);
    } else if (leadData.new_stage === 'proposal') {
      // Send proposal notification
      // await sendProposalSentEmail(leadData.email, leadData.name);
    } else if (leadData.new_stage === 'active') {
      // Convert to client and send welcome
      // await sendClientWelcome(leadData.email, leadData.name, leadData.church_name);
    }

    // Create follow-up task for sales team
    // await db.tasks.create({
    //   data: {
    //     title: `${leadData.name} moved to ${leadData.new_stage}`,
    //     description: `Follow up on stage change`,
    //     assigned_to: 'admin@erskinecurrie.com',
    //     due_date: new Date(Date.now() + 24 * 60 * 60 * 1000),
    //     status: 'pending',
    //     priority: 'medium'
    //   }
    // });

    console.log('Lead stage change automation completed');
    return { success: true, message: 'Stage change processed' };
  } catch (error) {
    console.error('Lead stage change webhook failed:', error);
    return { success: false, error: String(error) };
  }
}

/**
 * Webhook: Event Registration Completed
 * Triggered when someone registers for an event
 */
export async function onEventRegistration(registrationData: {
  id: string;
  event_id: string;
  name: string;
  email: string;
  event_title: string;
  event_date: string;
  event_location: string;
}) {
  console.log(`Event registration webhook: ${registrationData.email} → ${registrationData.event_title}`);

  try {
    // Send confirmation email immediately
    await sendEventConfirmation(
      registrationData.email,
      registrationData.name,
      registrationData.event_title,
      registrationData.event_date,
      registrationData.event_location
    );

    // Schedule reminder email for 24 hours before event
    // const eventDate = new Date(registrationData.event_date);
    // const reminderDate = new Date(eventDate.getTime() - 24 * 60 * 60 * 1000);
    // 
    // await scheduleEmail({
    //   type: 'event_reminder',
    //   to: registrationData.email,
    //   data: registrationData,
    //   sendAt: reminderDate
    // });

    // Update event registered count
    // await db.events.update({
    //   id: registrationData.event_id,
    //   data: { registered: { $increment: 1 } }
    // });

    console.log('Event registration automation completed');
    return { success: true, message: 'Registration confirmation sent' };
  } catch (error) {
    console.error('Event registration webhook failed:', error);
    return { success: false, error: String(error) };
  }
}

/**
 * Webhook: New Client Onboarded
 * Triggered when a lead converts to an active client
 */
export async function onNewClientOnboarded(clientData: {
  id: string;
  name: string;
  email: string;
  church_name: string;
  service_type: string;
}) {
  console.log(`New client onboarded: ${clientData.church_name}`);

  try {
    // Send welcome email series
    await sendClientWelcome(clientData.email, clientData.name, clientData.church_name);

    // Create onboarding tasks
    // const onboardingTasks = [
    //   { title: 'Send welcome packet', days: 0 },
    //   { title: 'Schedule kickoff call', days: 1 },
    //   { title: 'Share client portal access', days: 1 },
    //   { title: 'Deliver initial assessment', days: 7 },
    //   { title: '30-day check-in', days: 30 }
    // ];
    // 
    // for (const task of onboardingTasks) {
    //   await db.tasks.create({
    //     data: {
    //       title: task.title,
    //       description: `Onboarding: ${clientData.church_name}`,
    //       assigned_to: 'admin@erskinecurrie.com',
    //       due_date: new Date(Date.now() + task.days * 24 * 60 * 60 * 1000),
    //       status: 'pending',
    //       priority: 'high'
    //     }
    //   });
    // }

    // Schedule follow-up emails
    // await scheduleEmail({
    //   type: 'client_checkin',
    //   to: clientData.email,
    //   data: clientData,
    //   sendAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
    // });

    console.log('Client onboarding automation completed');
    return { success: true, message: 'Client onboarding initiated' };
  } catch (error) {
    console.error('Client onboarding webhook failed:', error);
    return { success: false, error: String(error) };
  }
}

/**
 * Webhook: Resource Downloaded
 * Triggered when someone downloads a gated resource
 */
export async function onResourceDownloaded(downloadData: {
  resource_id: string;
  resource_title: string;
  user_email: string;
  user_name: string;
  is_new_lead: boolean;
}) {
  console.log(`Resource downloaded: ${downloadData.resource_title} by ${downloadData.user_email}`);

  try {
    // Send resource confirmation email
    await sendResourceDownload(
      downloadData.user_email,
      downloadData.user_name,
      downloadData.resource_title
    );

    // If this is a new lead, trigger lead nurture sequence
    if (downloadData.is_new_lead) {
      // await onNewLeadCreated({
      //   email: downloadData.user_email,
      //   name: downloadData.user_name,
      //   source: 'resource_download',
      //   stage: 'inquiry'
      // });
    }

    // Track download analytics
    // await db.resources.update({
    //   id: downloadData.resource_id,
    //   data: { downloads: { $increment: 1 } }
    // });

    console.log('Resource download automation completed');
    return { success: true, message: 'Download confirmation sent' };
  } catch (error) {
    console.error('Resource download webhook failed:', error);
    return { success: false, error: String(error) };
  }
}

/**
 * Webhook: New Message Received
 * Triggered when a client sends a message
 */
export async function onNewMessageReceived(messageData: {
  id: string;
  sender_name: string;
  sender_email: string;
  subject: string;
  content: string;
  church_id: string;
}) {
  console.log(`New message received from: ${messageData.sender_email}`);

  try {
    // Send notification to admin
    // await sendNewMessageNotification('admin@erskinecurrie.com', messageData);

    // Create task for response
    // await db.tasks.create({
    //   data: {
    //     title: `Respond to message from ${messageData.sender_name}`,
    //     description: `Subject: ${messageData.subject}`,
    //     assigned_to: 'admin@erskinecurrie.com',
    //     due_date: new Date(Date.now() + 24 * 60 * 60 * 1000),
    //     status: 'pending',
    //     priority: 'high'
    //   }
    // });

    // Update church last_contact timestamp
    // await db.churches.update({
    //   id: messageData.church_id,
    //   data: { last_contact: new Date() }
    // });

    console.log('New message automation completed');
    return { success: true, message: 'Message notification sent' };
  } catch (error) {
    console.error('New message webhook failed:', error);
    return { success: false, error: String(error) };
  }
}

/**
 * Webhook: Task Completed
 * Triggered when a task is marked as complete
 */
export async function onTaskCompleted(taskData: {
  id: string;
  title: string;
  assigned_to: string;
  church_id?: string;
}) {
  console.log(`Task completed: ${taskData.title}`);

  try {
    // If task is related to a church, update engagement metrics
    if (taskData.church_id) {
      // await db.churches.update({
      //   id: taskData.church_id,
      //   data: { 
      //     last_contact: new Date(),
      //     engagement_score: { $increment: 5 }
      //   }
      // });
    }

    // Check if there are follow-up tasks to create
    // This would be based on task type and workflow rules

    console.log('Task completion automation completed');
    return { success: true, message: 'Task completion processed' };
  } catch (error) {
    console.error('Task completion webhook failed:', error);
    return { success: false, error: String(error) };
  }
}

// Export all webhook handlers
export default {
  onNewLeadCreated,
  onLeadStageChanged,
  onEventRegistration,
  onNewClientOnboarded,
  onResourceDownloaded,
  onNewMessageReceived,
  onTaskCompleted,
};