import logging
import os
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
import stripe

from core.database import get_db
from dependencies.auth import get_current_user
from schemas.auth import UserResponse

# Configure Stripe
stripe.api_key = os.environ.get("STRIPE_SECRET_KEY")

router = APIRouter(prefix="/api/v1/stripe", tags=["stripe"])

class CreateCheckoutSessionRequest(BaseModel):
    price_id: str
    success_url: str
    cancel_url: str

class CheckoutSessionResponse(BaseModel):
    session_id: str
    url: str

class PortalSessionRequest(BaseModel):
    return_url: str

class PortalSessionResponse(BaseModel):
    url: str

@router.post("/create-checkout-session", response_model=CheckoutSessionResponse)
async def create_checkout_session(
    data: CreateCheckoutSessionRequest,
    request: Request,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a Stripe checkout session for subscription"""
    try:
        # Get frontend host
        frontend_host = request.headers.get("App-Host")
        if frontend_host and not frontend_host.startswith(("http://", "https://")):
            frontend_host = f"https://{frontend_host}"
        
        # Create Stripe checkout session
        session = stripe.checkout.Session.create(
            customer_email=current_user.email,
            mode="subscription",
            payment_method_types=["card"],
            line_items=[{
                "price": data.price_id,
                "quantity": 1,
            }],
            success_url=f"{frontend_host}{data.success_url}?session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=f"{frontend_host}{data.cancel_url}",
            metadata={
                "user_id": current_user.id
            }
        )
        
        return CheckoutSessionResponse(
            session_id=session.id,
            url=session.url
        )
    except Exception as e:
        logging.error(f"Stripe checkout session creation error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create checkout session: {str(e)}")

@router.post("/create-portal-session", response_model=PortalSessionResponse)
async def create_portal_session(
    data: PortalSessionRequest,
    current_user: UserResponse = Depends(get_current_user),
):
    """Create a Stripe customer portal session for managing subscription"""
    try:
        # Get customer by email
        customers = stripe.Customer.list(email=current_user.email, limit=1)
        
        if not customers.data:
            raise HTTPException(status_code=404, detail="No Stripe customer found")
        
        customer_id = customers.data[0].id
        
        # Create portal session
        session = stripe.billing_portal.Session.create(
            customer=customer_id,
            return_url=data.return_url,
        )
        
        return PortalSessionResponse(url=session.url)
    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Stripe portal session creation error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create portal session: {str(e)}")

@router.post("/webhook")
async def stripe_webhook(request: Request, db: AsyncSession = Depends(get_db)):
    """Handle Stripe webhook events"""
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")
    webhook_secret = os.environ.get("STRIPE_WEBHOOK_SECRET")
    
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, webhook_secret
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payload")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Invalid signature")
    
    # Handle the event
    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        user_id = session["metadata"]["user_id"]
        # TODO: Update user subscription status in database
        logging.info(f"Checkout completed for user {user_id}")
    
    elif event["type"] == "customer.subscription.updated":
        subscription = event["data"]["object"]
        # TODO: Update subscription status in database
        logging.info(f"Subscription updated: {subscription['id']}")
    
    elif event["type"] == "customer.subscription.deleted":
        subscription = event["data"]["object"]
        # TODO: Handle subscription cancellation
        logging.info(f"Subscription cancelled: {subscription['id']}")
    
    return {"status": "success"}

@router.get("/products")
async def get_products():
    """Get available subscription products"""
    try:
        products = stripe.Product.list(active=True, limit=10)
        prices = stripe.Price.list(active=True, limit=20)
        
        # Combine products with their prices
        product_list = []
        for product in products.data:
            product_prices = [p for p in prices.data if p.product == product.id]
            product_list.append({
                "id": product.id,
                "name": product.name,
                "description": product.description,
                "prices": [{
                    "id": price.id,
                    "amount": price.unit_amount,
                    "currency": price.currency,
                    "interval": price.recurring.interval if price.recurring else None,
                } for price in product_prices]
            })
        
        return {"products": product_list}
    except Exception as e:
        logging.error(f"Error fetching Stripe products: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch products: {str(e)}")