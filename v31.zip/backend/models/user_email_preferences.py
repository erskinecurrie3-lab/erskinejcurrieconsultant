from core.database import Base
from sqlalchemy import Boolean, Column, Integer, String


class User_email_preferences(Base):
    __tablename__ = "user_email_preferences"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    email_on_reply = Column(Boolean, nullable=True)
    email_on_instructor_response = Column(Boolean, nullable=True)
    email_on_upvote = Column(Boolean, nullable=True)
    email_on_mention = Column(Boolean, nullable=True)
    digest_frequency = Column(String, nullable=True)
    last_digest_sent = Column(String, nullable=True)
    created_at = Column(String, nullable=True)
    updated_at = Column(String, nullable=True)