from core.database import Base
from sqlalchemy import Column, Integer, String


class Discussion_upvotes(Base):
    __tablename__ = "discussion_upvotes"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    discussion_id = Column(Integer, nullable=True)
    reply_id = Column(Integer, nullable=True)
    user_id = Column(String, nullable=False)
    created_at = Column(String, nullable=True)