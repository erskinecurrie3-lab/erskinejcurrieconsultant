from core.database import Base
from sqlalchemy import Boolean, Column, Integer, String


class Discussion_notifications(Base):
    __tablename__ = "discussion_notifications"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    discussion_id = Column(Integer, nullable=False)
    reply_id = Column(Integer, nullable=True)
    notification_type = Column(String, nullable=False)
    is_read = Column(Boolean, nullable=True)
    created_at = Column(String, nullable=True)