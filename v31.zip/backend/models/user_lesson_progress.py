from core.database import Base
from sqlalchemy import Boolean, Column, Integer, String


class User_lesson_progress(Base):
    __tablename__ = "user_lesson_progress"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    lesson_id = Column(Integer, nullable=False)
    is_completed = Column(Boolean, nullable=True)
    completed_at = Column(String, nullable=True)