from core.database import Base
from sqlalchemy import Column, Integer, String


class Proposals(Base):
    __tablename__ = "proposals"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    lead_id = Column(Integer, nullable=True)
    church_id = Column(Integer, nullable=True)
    title = Column(String, nullable=False)
    content = Column(String, nullable=True)
    services = Column(String, nullable=True)
    total_amount = Column(Integer, nullable=True)
    status = Column(String, nullable=False)
    sent_at = Column(String, nullable=True)
    user_id = Column(String, nullable=False)
    created_at = Column(String, nullable=False)
    updated_at = Column(String, nullable=True)