from core.database import Base
from sqlalchemy import Boolean, Column, Integer, String


class Messages(Base):
    __tablename__ = "messages"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    church_id = Column(Integer, nullable=False)
    sender_type = Column(String, nullable=False)
    subject = Column(String, nullable=True)
    content = Column(String, nullable=False)
    read = Column(Boolean, nullable=True)
    user_id = Column(String, nullable=False)
    created_at = Column(String, nullable=False)