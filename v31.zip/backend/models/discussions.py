from core.database import Base
from sqlalchemy import Boolean, Column, Integer, String


class Discussions(Base):
    __tablename__ = "discussions"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    course_id = Column(Integer, nullable=False)
    lesson_id = Column(Integer, nullable=True)
    user_id = Column(String, nullable=False)
    title = Column(String, nullable=False)
    content = Column(String, nullable=False)
    is_pinned = Column(Boolean, nullable=True)
    is_resolved = Column(Boolean, nullable=True)
    upvotes = Column(Integer, nullable=True)
    created_at = Column(String, nullable=True)
    updated_at = Column(String, nullable=True)