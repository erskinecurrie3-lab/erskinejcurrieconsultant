from core.database import Base
from sqlalchemy import Boolean, Column, Integer, String


class Registrations(Base):
    __tablename__ = "registrations"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    event_id = Column(Integer, nullable=False)
    church_id = Column(Integer, nullable=True)
    attendee_name = Column(String, nullable=False)
    attendee_email = Column(String, nullable=False)
    attendee_phone = Column(String, nullable=True)
    payment_status = Column(String, nullable=False)
    payment_amount = Column(Integer, nullable=True)
    stripe_session_id = Column(String, nullable=True)
    attended = Column(Boolean, nullable=True)
    user_id = Column(String, nullable=False)
    created_at = Column(String, nullable=False)
    updated_at = Column(String, nullable=True)