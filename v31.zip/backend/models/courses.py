from core.database import Base
from sqlalchemy import Boolean, Column, Float, Integer, String


class Courses(Base):
    __tablename__ = "courses"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    title = Column(String, nullable=False)
    description = Column(String, nullable=True)
    thumbnail_url = Column(String, nullable=True)
    instructor_id = Column(String, nullable=False)
    category = Column(String, nullable=True)
    difficulty_level = Column(String, nullable=True)
    duration_hours = Column(Float, nullable=True)
    price = Column(Float, nullable=True)
    is_published = Column(Boolean, nullable=True)
    created_at = Column(String, nullable=True)
    updated_at = Column(String, nullable=True)