from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class Enrollments(Base):
    __tablename__ = "enrollments"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    course_id = Column(Integer, nullable=False)
    enrolled_at = Column(String, nullable=True)
    completion_percentage = Column(Float, nullable=True)
    status = Column(String, nullable=True)
    last_accessed_at = Column(String, nullable=True)