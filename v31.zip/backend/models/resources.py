from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Integer, String


class Resources(Base):
    __tablename__ = "resources"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    title = Column(String, nullable=False)
    description = Column(String, nullable=True)
    category = Column(String, nullable=False)
    file_url = Column(String, nullable=True)
    thumbnail_url = Column(String, nullable=True)
    preview_url = Column(String, nullable=True)
    downloads = Column(Integer, nullable=True)
    is_gated = Column(Boolean, nullable=True)
    topic = Column(String, nullable=True)
    audience = Column(String, nullable=True)
    tags = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)