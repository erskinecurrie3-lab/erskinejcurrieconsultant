from core.database import Base
from sqlalchemy import Column, Float, Integer, String


class User_course_progress(Base):
    __tablename__ = "user_course_progress"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    course_id = Column(Integer, nullable=False)
    enrollment_date = Column(String, nullable=True)
    completion_percentage = Column(Float, nullable=True)
    last_accessed = Column(String, nullable=True)
    completed_at = Column(String, nullable=True)