from core.database import Base
from sqlalchemy import Column, Integer, String


class Events(Base):
    __tablename__ = "events"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    title = Column(String, nullable=False)
    description = Column(String, nullable=True)
    event_type = Column(String, nullable=False)
    start_date = Column(String, nullable=False)
    end_date = Column(String, nullable=True)
    location = Column(String, nullable=True)
    capacity = Column(Integer, nullable=True)
    price = Column(Integer, nullable=True)
    status = Column(String, nullable=False)
    image_url = Column(String, nullable=True)
    created_at = Column(String, nullable=False)
    updated_at = Column(String, nullable=True)