from core.database import Base
from sqlalchemy import Column, Integer, String


class Modules(Base):
    __tablename__ = "modules"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    course_id = Column(Integer, nullable=False)
    title = Column(String, nullable=False)
    description = Column(String, nullable=True)
    order_index = Column(Integer, nullable=True)
    created_at = Column(String, nullable=True)
    updated_at = Column(String, nullable=True)