from core.database import Base
from sqlalchemy import Boolean, Column, Integer, String


class Discussion_replies(Base):
    __tablename__ = "discussion_replies"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    discussion_id = Column(Integer, nullable=False)
    parent_reply_id = Column(Integer, nullable=True)
    user_id = Column(String, nullable=False)
    content = Column(String, nullable=False)
    upvotes = Column(Integer, nullable=True)
    is_instructor_response = Column(Boolean, nullable=True)
    created_at = Column(String, nullable=True)
    updated_at = Column(String, nullable=True)