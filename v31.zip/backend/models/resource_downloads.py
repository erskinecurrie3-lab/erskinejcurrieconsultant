from core.database import Base
from sqlalchemy import Column, Integer, String


class Resource_downloads(Base):
    __tablename__ = "resource_downloads"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    resource_id = Column(Integer, nullable=False)
    resource_title = Column(String, nullable=False)
    user_email = Column(String, nullable=False)
    download_timestamp = Column(String, nullable=True)
    source = Column(String, nullable=False)