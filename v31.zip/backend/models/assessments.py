from core.database import Base
from sqlalchemy import Column, Integer, String


class Assessments(Base):
    __tablename__ = "assessments"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    church_id = Column(Integer, nullable=False)
    title = Column(String, nullable=False)
    category = Column(String, nullable=False)
    score = Column(Integer, nullable=False)
    responses = Column(String, nullable=True)
    recommendations = Column(String, nullable=True)
    completed_at = Column(String, nullable=True)
    user_id = Column(String, nullable=False)
    created_at = Column(String, nullable=False)