from core.database import Base
from sqlalchemy import Column, Integer, String


class Leads(Base):
    __tablename__ = "leads"
    __table_args__ = {"extend_existing": True}

    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    phone = Column(String, nullable=True)
    church_name = Column(String, nullable=True)
    role = Column(String, nullable=True)
    stage = Column(String, nullable=False)
    source = Column(String, nullable=True)
    score = Column(Integer, nullable=True)
    tags = Column(String, nullable=True)
    notes = Column(String, nullable=True)
    user_id = Column(String, nullable=False)
    created_at = Column(String, nullable=False)
    updated_at = Column(String, nullable=True)